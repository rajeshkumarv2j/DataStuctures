package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

/*
*
* @author Varma 
*
*/
public class Student implements InitializingBean, DisposableBean {
	private String studentNo;

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println(".Student.afterPropertiesSet()");
		// Logic -- SessionFactory Creation/ JNDI Lookup using injected
		// values...etc/ Means using studentNo etc...
	}

	public void destroy() throws Exception {
		System.out.println(".Student.destroy()");
		// Logic -- SessionFactory closing ...etc
	}

	public String getStudentNo() {
		return studentNo;
	}

}
