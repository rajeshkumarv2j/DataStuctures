package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class BeanLifeCycleTest {
	private static AbstractApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		Student student = (Student) context.getBean("student");
		System.out.println(".StudentNo." + student.getStudentNo());
		context.close();
	}
}
