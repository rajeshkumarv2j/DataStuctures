package edu.message;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class HelloMessage implements Message{

	public String getMessage() {
		return "HelloMessage";
	}
	

}
