package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.Dao;

/*
*
* @author Varma 
*
*/
public abstract class Service {
	public abstract Dao getDao();

	public void serviceMethod() {
		getDao().daoMethod();
		System.out.println(".Dao Ref :" + getDao());
	}
}
