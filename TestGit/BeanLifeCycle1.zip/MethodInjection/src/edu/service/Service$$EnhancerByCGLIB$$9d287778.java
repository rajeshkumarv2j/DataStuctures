package edu.service;

import edu.dao.Dao;

public class Service$$EnhancerByCGLIB$$9d287778 extends Service {

	@Override
	public Dao getDao() {
		return new Dao();
	}

}