package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class SetTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		Student student = (Student) context.getBean("student");
		Set studentSet = student.getStudentSet();
		String[] studentArray = student.getStringArray();
		System.out.println("studentSet." + studentSet);
		// Iterate studentSet and StudentArray
	}
}
