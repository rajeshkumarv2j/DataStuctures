package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.service.ServiceOne;
import edu.service.ServiceTwo;

/*
*
* @author Varma 
*
*/
public class DefaultAutowireTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		ServiceOne serviceOne = (ServiceOne) context.getBean("serviceOne");
		System.out.println(".ServiceOne.serviceMethod()-Call");
		serviceOne.serviceMethod();
		ServiceTwo serviceTwo = (ServiceTwo) context.getBean("serviceTwo");
		System.out.println(".serviceTwo.serviceMethod()-Call");
		serviceTwo.serviceMethod();

	}
}
