package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.Dao;

/*
*
* @author Varma 
*
*/
public class ServiceTwo {
	private Dao dao;

	public ServiceTwo(Dao dao) {
		this.dao = dao;
		System.out.println(".ServiceTwo.Service(Dao)");
	}

	public void serviceMethod() {
		System.out.println(".ServiceTwo.serviceMethod().START");
		dao.daoMethod();
		System.out.println(".ServiceTwo.serviceMethod().END");
	}

}
