package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.List;

/*
*
* @author Varma 
*
*/
public class Student {
	private List studentList;

	public List getStudentList() {
		return studentList;
	}

	public void setStudentList(List studentList) {
		this.studentList = studentList;
	}

	public void studentMethod() {
		// Implement the common Logic using studentList
	}
}
