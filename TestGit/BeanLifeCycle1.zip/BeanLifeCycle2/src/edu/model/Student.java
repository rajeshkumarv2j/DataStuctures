package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class Student {
	private String studentNo;

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println(".Student.afterPropertiesSet()");
		// Logic -- SessionFactory Creation/ JNDI Lookup using injected
		// values...etc/ Means using studentNo etc...
	}

	public void destroyTest() throws Exception {
		// Logic -- SessionFactory closing ...etc
		System.out.println(".Student.destroyTest()");
	}

	public String getStudentNo() {
		return studentNo;
	}

}
