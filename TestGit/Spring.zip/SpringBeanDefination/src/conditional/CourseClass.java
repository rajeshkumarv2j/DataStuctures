package conditional;

/**
 * Created by mt on 26.03.2015.
 */
public interface CourseClass {
    String courseName();
}
