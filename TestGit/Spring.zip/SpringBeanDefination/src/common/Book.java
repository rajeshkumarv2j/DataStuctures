package common;

/**
 * Created by mt on 26.03.2015.
 */
/**
 * Yes, books do talk.
 */
public interface Book {
    String talk();
}
