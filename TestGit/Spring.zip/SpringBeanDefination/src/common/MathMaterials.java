package common;

/**
 * Created by mt on 27.03.2015.
 */
public class MathMaterials {
    private final int count;

    public MathMaterials(int count) {
        this.count = count;
    }

    public int getCount(){
        return count;
    }
}
