package com.logicbig.example.client;

import com.logicbig.example.service.OrderService;

import javax.annotation.Resource;
import java.util.Arrays;


public class OrderServiceClient {

    @Resource(name = "OrderServiceA")
    private OrderService orderService;

    public void showPendingOrderDetails() {
        for (String orderId : Arrays.asList("100", "200", "300")) {
            System.out.println(orderService.getOrderDetails(orderId));
        }
    }
}