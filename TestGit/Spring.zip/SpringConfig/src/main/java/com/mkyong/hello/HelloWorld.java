package com.mkyong.hello;
 
public interface HelloWorld {
	
	void printHelloWorld(String msg);
 
}