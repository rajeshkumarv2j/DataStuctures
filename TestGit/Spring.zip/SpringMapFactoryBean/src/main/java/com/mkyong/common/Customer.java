package com.mkyong.common;

import java.util.Map;

public class Customer {

	private Map maps;

	public Map getMaps() {
		return maps;
	}

	public void setMaps(Map maps) {
		this.maps = maps;
	}

	@Override
	public String toString() {
		return "Customer [maps=" + maps + "]";
	}

	
}