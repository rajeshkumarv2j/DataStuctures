package com.mkyong.core;

public class CustomerBo {

	public void printMsg(String msg) {

		System.out.println("CustomerBo : " + msg);
	}

}