package com.mkyong.core;

public class SchedulerBo {

	public void printMsg(String msg) {

		System.out.println("SchedulerBo : " + msg);
	}

}