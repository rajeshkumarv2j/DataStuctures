package com.logicbig.example.service;


public interface OrderService {

    String getOrderDetails(String orderId);
}