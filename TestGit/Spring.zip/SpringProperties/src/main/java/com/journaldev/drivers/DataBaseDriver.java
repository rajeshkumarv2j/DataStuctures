package com.journaldev.drivers;

public interface DataBaseDriver {
    public String getInfo();
}
